package com.example.collegeeventmanagement;

public class Spinner {

}
